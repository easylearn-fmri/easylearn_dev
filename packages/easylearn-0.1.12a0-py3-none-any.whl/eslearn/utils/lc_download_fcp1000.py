
urllib.request.urlretrieve('https://fcp-indi.s3.amazonaws.com/data/Projects/FCON1000/AnnArbor_a/sourcedata/sub-04111/anat/sub-04111_T1w.nii.gz',
                           r'F:\Data\ASD\Outputs\cpac\nofilt_noglobal\reho\test1.tar')


import numpy as np
d = np.load(r'F:\Data\Caltech_0051456_rois_cc200.1D')
# -*- coding: utf-8 -*-
"""
Created on Mon Mar 25 20:53:20 2019
用来提取头动参数
@author: lenovo
"""
